package com.javaguides.company.emplois.services;

import com.javaguides.company.emplois.external.dummyjson.DummyJsonService;
import com.javaguides.company.emplois.model.Brand;
import com.javaguides.company.emplois.model.Category;
import com.javaguides.company.emplois.repository.BrandRepository;
import com.javaguides.company.emplois.repository.CategoryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class BrandService {
    private Logger LOG = LoggerFactory.getLogger(this.getClass());
    private final BrandRepository brandRepository;
    private final DummyJsonService dummyJsonService;
    private final CategoryRepository categoryRepository ;
    @Autowired
    public BrandService(BrandRepository brandRepository,  DummyJsonService dummyJsonService, CategoryRepository categoryRepository1) {
        this.brandRepository = brandRepository;
        this.dummyJsonService = dummyJsonService;
        this.categoryRepository = categoryRepository1;
    }

    public List<Brand> saveDummyBrands() {
        LOG.info("saveDummyBrands");
        List<Brand> dummyBrands = dummyJsonService.getDummyBrands();
        for(Brand brand : dummyBrands) {
            Brand newBrand = this.getBrand(brand.getName());

            if(newBrand == null){
                brandRepository.save(brand);
                LOG.info("LOCAL ADD: {}", brand);
            }
        }
        return dummyBrands;
    }

    public Brand getBrand(String name){
        LOG.info("getBrand string:{}",name);
        Optional<Brand> brand = brandRepository.findByName(name);
        return brand.orElse(null);
    }
    public Brand getBrand(long id){
        LOG.info("getBrand long:{}",id);
        Optional<Brand> brand = brandRepository.findById(id);
        return brand.orElse(null);
    }

    public Brand addBrand(Brand brand){
        LOG.info("addBrand :{}",brand);
        return brandRepository.save(brand);
    }

    public Brand updateBrand(Brand brand){
        LOG.info("updateBrand :{}",brand);
        return brandRepository.save(brand);
    }

    public void removeBrand(long id) {
        LOG.info("removeBrand :{}",id);
        Brand brand =this.getBrand(id);
        if(brand != null) {
            brandRepository.delete(brand);
        }
    }

    public List<Category> getCategories(){
        LOG.info("running: getCategories");
        List<Category> categories = categoryRepository.findAll();
        if(categories.isEmpty()){
            categories = dummyJsonService.getDummyCategories();
            LOG.info("categories size: {}", categories.size());
            categories.forEach( category -> LOG.info("category : {}",category.toString()));
        }
        return categories;
    }

    public List<Category> getBrandCategories(String brandName) {
        return new ArrayList<>();
    }
}
