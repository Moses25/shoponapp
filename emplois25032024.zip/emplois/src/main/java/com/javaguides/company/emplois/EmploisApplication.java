package com.javaguides.company.emplois;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@ComponentScan(basePackages = "com.javaguides.company.external.dummyjson")
public class EmploisApplication {
//	@Autowired
//	private DummyJsonService dummyJsonService;
	private final Logger LOG = LoggerFactory.getLogger(this.getClass());
	public static void main(String[] args) {
		SpringApplication.run(EmploisApplication.class, args);
	}

//	@Bean
//	public DummyJsonService dummyJsonService(){
//		return new DummyJsonService();
//	}
//	@Bean
//	public RestTemplate restTemplate(RestTemplateBuilder builder){
//		LOG.info("called restTemplate()");
////		return builder.build();
//		return new RestTemplate();
//	}
//
//	@Bean
////	@Profile("!test")
//	public CommandLineRunner run(RestTemplate restTemplate) throws Exception{
//	LOG.info("run of CommandLineRunner called");
//        return args -> {
//            User user = restTemplate.getForObject("https://jsonplaceholder.typicode.com/users/1", User.class);
//            LOG.info("user jsonplaceholder:  {}", user);
//            LOG.info("---------------------------------user email:  {}", user.getEmail());
//        };
//	}
}
