package com.javaguides.company.emplois.services;

import com.javaguides.company.emplois.external.dummyjson.DummyJsonService;
import com.javaguides.company.emplois.model.Product;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class ProductService {
    private DummyJsonService dummyJsonService;

    private final Logger LOG = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ProductService( DummyJsonService dummyJsonService){
        this.dummyJsonService=dummyJsonService;
    }

    public void removeProduct(long id){

    }

    public void addProduct(Product product){

    }

    public void updateProduct(Product product){

    }
    public void listProductsByCat(String category){

    }
    public void listProductsByBrand(String brand){

    }
    public void retrieveProducts(long id){

    }

    public List<Product> getDiscountedProducts(){
        return new ArrayList<Product>();
    }

    public List<Product> getAllProducts(){
        LOG.info("Product service getAllProducts");
        return dummyJsonService.getDummyJsonProducts();
    }
}
