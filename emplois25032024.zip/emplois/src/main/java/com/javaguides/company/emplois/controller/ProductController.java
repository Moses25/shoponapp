package com.javaguides.company.emplois.controller;

import com.javaguides.company.emplois.model.Product;
import com.javaguides.company.emplois.services.ProductService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "api/v1/products")
public class ProductController {
    private final Logger LOG = LoggerFactory.getLogger(this.getClass());
    private final ProductService productService;

    public ProductController(ProductService productService){
        this.productService=productService;
    }

//    @GetMapping(path ={"","brand/{brand}","category/{category}"})
//    public List<Product> getProducts() {
//
//    }

    @GetMapping("{id}")
    public Product getProduct(@PathVariable("id") int id) {
        Product product = new Product();
        LOG.info("Get product at {}", id);
        LOG.info("LOCAL ADD product at {}", id);
        return product;
    }

    @PutMapping
    public Product updateProduct(Product product) {
        LOG.info("product before update: {}", product);
        LOG.info("product after update: {}", product);
        return product;
    }

    @DeleteMapping
    public void removeProduct() {

    }

    @GetMapping
    public List<Product> getAllProduct() {
        return productService.getAllProducts();
    }

}
