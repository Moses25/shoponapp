package com.javaguides.company.emplois.services;

import com.javaguides.company.emplois.external.dummyjson.DummyJsonService;
import com.javaguides.company.emplois.model.User;
import com.javaguides.company.emplois.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsersService {
    private final Logger LOG = LoggerFactory.getLogger(this.getClass());
    private final DummyJsonService dummyJsonService;
    private final UserRepository userRepository;
    public UsersService(DummyJsonService dummyJsonService, UserRepository userRepository) {
        this.dummyJsonService = dummyJsonService;
        this.userRepository = userRepository;
    }

    public User saveUser(User user){
        LOG.info("saving user with id " + user.getId());
        return userRepository.save(user);
    }

    public List<User> saveUsers(List<User> users) {
        return userRepository.saveAll(users);
    }

    public User getUser(long id) {
        Optional<User> optionalUser = userRepository.findById(id);
        LOG.info("GET user @id : {}",id);
        if (optionalUser.isEmpty()) {
            User user = dummyJsonService.getDummyUserById(id);
            Optional<User> byEmailUser = Optional.empty();
            if(user != null) {
                byEmailUser = userRepository.findByEmail(user.getEmail());
            }
            if(byEmailUser.isPresent()){
                LOG.info("search for ID:{} email in use by user @ ID:{}", id, byEmailUser.get().getId());
                return null;
            }
            LOG.info("LOCAL ADD : {}",user);
            return this.saveUser(user);
        }//                return  byEmailUser.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"user was not found or password wrong lol"));
        return optionalUser.get();
    }

    public List<User> getUsers(int skip){
        List<User> users = dummyJsonService.getDummyUsers(skip);
        LOG.info("LOCAL ADD list of users: ");
        users.forEach(user -> LOG.info(user.toString()));
        return userRepository.saveAll(users);
    }

    public User updateUser(User user) {
        User olderUser = this.getUser(user.getId());
        LOG.info("Current user: {}", olderUser);
        olderUser = user;
        LOG.info("change user to : {}", user);
        return userRepository.save(user);
    }

    public User getUserByEmail(String email) {
        Optional<User> byEmailUser = userRepository.findByEmail(email);
        return byEmailUser.orElse(null);
    }
    public List<User> getUserByLastName(String lastName){
        List<User> users = userRepository.findByLastName(lastName);
        LOG.info("Get users by lastname: ");
        users.forEach(user -> LOG.info(user.toString()));
        return users;
    }

}
