package com.javaguides.company.emplois.external.dummyjson;

import com.javaguides.company.emplois.model.DummyJsonServiceUserResponse;
import com.javaguides.company.emplois.model.Brand;
import com.javaguides.company.emplois.model.Category;
import com.javaguides.company.emplois.model.Product;
import com.javaguides.company.emplois.model.User;
import com.javaguides.company.emplois.services.DummyJsonServiceBrandResponse;
import com.javaguides.company.emplois.services.DummyJsonServiceCategoriesResponse;
import com.javaguides.company.emplois.services.DummyJsonServiceProductResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.ArrayList;
import java.util.List;

@Service
public class DummyJsonService {
    private Logger LOG = LoggerFactory.getLogger(this.getClass());

    private final RestClient restClient;

    public DummyJsonService() {
        this.restClient = RestClient.builder()
                .baseUrl("https://dummyjson.com")
                .build();
    }

    public List<User> getDummyUsers(int skip) {
        LOG.info("getDummyUsers : running getDummyUsers list"  );
        DummyJsonServiceUserResponse dummyJsonServiceUserResponse = restClient.get()
                .uri("/users?skip="+skip+"&select=firstName,age,email,lastName,gender")
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .body(DummyJsonServiceUserResponse.class);
                LOG.info("Total number of users fetched: " + dummyJsonServiceUserResponse.users().size());
        return dummyJsonServiceUserResponse.users();
    }
    public User getDummyUserById(long id) {
        LOG.info("getDummyUserById : running getDummyUserById uri=" + id);
        return restClient.get()
                .uri("/users/"+id+"?select=firstName,age,email,lastName,gender")
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .body(User.class);
    }

    public List<Brand> getDummyBrands() {

        LOG.info("getDummyBrands : running"  );
        var respSpec = restClient.get()
                .uri("/products?select=brand")
//                .accept(MediaType.APPLICATION_JSON)
                .retrieve();
        DummyJsonServiceBrandResponse body = respSpec.body(DummyJsonServiceBrandResponse.class);
        if(body==null){
            return new ArrayList<>();
        }
        return body.brands();
    }
    public List<Category> getDummyCategories() {

        LOG.info("getDummyCategories : running"  );
        RestClient.ResponseSpec respSpec = restClient.get()
                .uri("/products?select=category")
//                .accept(MediaType.APPLICATION_JSON)
                .retrieve();
        DummyJsonServiceCategoriesResponse body = respSpec.body(DummyJsonServiceCategoriesResponse.class);
        LOG.info("DummyJsonServiceCategoriesResponse {}",body);
        if(body==null || body.products()  ==null){
            return new ArrayList<>();
        }
        LOG.info("getDummyCategories running : {}", body.products().size());
        return body.products();
    }

    public List<Product> getDummyJsonProducts() {
        LOG.info("getDummyJsonProducts : running"  );
        var respSpec = restClient.get()
                .uri("/products")
//                .accept(MediaType.APPLICATION_JSON)
                .retrieve();
        DummyJsonServiceProductResponse body = respSpec.body(DummyJsonServiceProductResponse.class);
        LOG.info("DummyJsonServiceProductResponse {}",body);
        if(body==null){
            return new ArrayList<>();
        }
        return body.products();
    }

}
