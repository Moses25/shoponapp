package com.javaguides.company.emplois.repository;

import com.javaguides.company.emplois.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Long> {

}
