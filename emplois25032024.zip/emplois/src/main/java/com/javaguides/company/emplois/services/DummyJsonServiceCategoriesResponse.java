package com.javaguides.company.emplois.services;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.javaguides.company.emplois.model.Brand;
import com.javaguides.company.emplois.model.Category;

import java.util.List;
public record DummyJsonServiceCategoriesResponse(@JsonAlias("products") List<Category> products, int total, int skip, int limit) {
}
