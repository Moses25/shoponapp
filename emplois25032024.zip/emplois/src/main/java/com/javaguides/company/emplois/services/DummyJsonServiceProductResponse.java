package com.javaguides.company.emplois.services;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.javaguides.company.emplois.model.Product;

import java.util.List;

public record DummyJsonServiceProductResponse(@JsonAlias("products") List<Product> products, int total, int skip, int limit) {
}
