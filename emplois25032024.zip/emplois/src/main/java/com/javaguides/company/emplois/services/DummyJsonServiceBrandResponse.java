package com.javaguides.company.emplois.services;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.javaguides.company.emplois.model.Brand;

import java.util.List;

public record DummyJsonServiceBrandResponse(@JsonAlias("products") List<Brand> brands, int total, int skip, int limit) {
}
