package com.javaguides.company.emplois.controller;

import com.javaguides.company.emplois.model.Brand;
import com.javaguides.company.emplois.model.Category;
import com.javaguides.company.emplois.services.BrandService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path= {"api/v1/brands","api/v1/brandlist"})
public class BrandController {
    private final BrandService brandService;
//    @Autowired
    public BrandController(BrandService brandService){
        this.brandService=brandService;
    }

    @PostMapping
    public Brand addBrands(Brand brand) {
        return brandService.addBrand(brand);
    }

    @PutMapping
    public Brand updateBrand(Brand brand) {
        return brandService.updateBrand(brand);
    }

    @DeleteMapping("/{id}")
    public void removeBrands(@PathVariable("id") long id) {
        brandService.removeBrand(id);
    }

    @GetMapping("name/{name}")
    public Brand getBrandName(@PathVariable String name) {
        return brandService.getBrand(name);
    }

    @GetMapping
    public List<Brand> getBrands() {
        return brandService.saveDummyBrands();
    }

    @GetMapping("/{id}")
    public Brand getBrand(@PathVariable String id) {
        return brandService.getBrand(id);
    }

    @GetMapping("/categories/{brand}")
    public List<Category> getBrandCategories(@PathVariable("brand") String brandName){
        return brandService.getBrandCategories(brandName);
    }

    @GetMapping("/category")
    public List<Category> getCategories(){
        return brandService.getCategories();
    }
}
