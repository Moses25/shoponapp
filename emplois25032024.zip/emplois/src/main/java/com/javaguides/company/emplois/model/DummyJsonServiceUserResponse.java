package com.javaguides.company.emplois.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.javaguides.company.emplois.model.User;

import java.util.List;

public record DummyJsonServiceUserResponse(@JsonAlias("users") List<User> users, int total, int skip, int limit) {
}
