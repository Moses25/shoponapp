package com.javaguides.company.emplois.controller;

import com.javaguides.company.emplois.model.User;
import com.javaguides.company.emplois.services.UsersService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController//tells spring that this handles web requests
@RequestMapping(path = "/api/v1/users/")//tells spring that this handles web requests
public class UsersController {

    private final Logger LOG = LoggerFactory.getLogger(this.getClass());

    private final UsersService usersService;
    public UsersController(UsersService usersService) {
        this.usersService = usersService;
    }

    @GetMapping(path = {"","skip/{skip}"})
    public List<User> getUsers(@PathVariable("skip") int skip){
        LOG.info("called getusers skip==" +  skip);
        return usersService.getUsers(skip);
    }

    @GetMapping(path="{id}")
    public User getUserByID(@PathVariable int id){
        return usersService.getUser(id);
    }

    @PutMapping()
    public User getUserByID(User user){
        return usersService.updateUser(user);
    }


    @GetMapping("/lastname/{lastname}")
    public List<User> getUserByLastName(@PathVariable String lastname){
        LOG.info("getUser controller lastname="+lastname);
        return usersService.getUserByLastName(lastname);
    }

    @GetMapping("/email/{email}")
    public User getUserByID(@PathVariable("email") String email){
        LOG.info("getUser controller email="+email);
        return usersService.getUserByEmail(email);
    }

    @GetMapping("/brands")
//    @ResponseBody //makes the dipatcher not look for the page
    public void getBrands(){
        LOG.info("emplois : Running getUsers");
//        return productService.getBrands();
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PostMapping
    public void addUser(@RequestBody User user){

    }
}
